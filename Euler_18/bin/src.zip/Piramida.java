public class Piramida {
	public int depth;
	public Node head;

	private int indexInRaw;
	private Node last;
	private Node firstOfRaw;

	public Piramida() {
		this.depth = 0;
		this.head = null;

		this.indexInRaw = 0;
		this.last = null;
		this.firstOfRaw = null;
	}
}
