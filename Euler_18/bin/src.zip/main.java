public class main {
	public static Piramida p;

	public static void main(String[] args) {
		p = new Piramida();

	}

}
